package main

func Add(value1 int, value2 int) int {
    return value1 + value2
}

func Subtract(value1 int, value2 int) int {
    return value1 - value2
}