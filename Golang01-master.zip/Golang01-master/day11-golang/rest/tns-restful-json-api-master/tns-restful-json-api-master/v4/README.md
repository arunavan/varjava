# Example 4

## Running the exmaple

To run this exmaple, from the root of this project:

```sh
go run ./v4/*.go
```
